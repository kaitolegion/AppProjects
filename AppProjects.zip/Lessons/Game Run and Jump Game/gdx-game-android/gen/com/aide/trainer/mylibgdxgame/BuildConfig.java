/** Automatically generated file. DO NOT MODIFY */
package com.aide.trainer.mylibgdxgame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}