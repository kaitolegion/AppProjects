import java.util.Scanner;
class main {
	public static void main(String[]args) 
	{
		Scanner input = new Scanner(System.in);
		int employees = 5;
		
// for loop Input String of Employees 5x
  
		String[] names = new String[employees];
		
		for (int name = 0; name < employees;name++){
			System.out.print("\n­ENTER NAME OF EMPLOYEE "+(name + 1)+ ":");
			names[name] = input.nextLine();
			}

// for loop Input Int of Hours work by employee 5x
		Float[] hours = new Float[employees];
		
		for (int hour=0; hour<employees; hour++){
		   System.out.println("\nENTER HOURS WORKED BY EMPLOYEE "+(hour + 1)+":");
		   hours[hour] = input.nextFloat();
	   }
	   
// Result Table

	   System.out.println("NAMES\tHOURS\tSALARY");
	   for (int name=0; name<employees;name++){
		System.out.println(names[name]+"   "+hours[name]+"   "+(hours[name]*174));
      }
		
}
}
