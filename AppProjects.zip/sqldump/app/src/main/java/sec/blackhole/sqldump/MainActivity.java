package sec.blackhole.sqldump;

import android.app.*;
import android.os.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.view.*;
import android.util.*;
import android.text.*;
import android.widget.*;
import android.view.View.*;
import java.io.*;
import java.net.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.*;
import android.content.Context;
import android.view.inputmethod.EditorInfo;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import com.google.android.gms.security.*;
import javax.net.ssl.*;

public class MainActivity extends Activity 
{
	private EditText dork;
	private GoogleSearchTask mTask;
	private int totalResult = 0;
	private ScrollView tscroll;
	private String results = "";
	private TextView console;
	
	public class GoogleSearchTask extends AsyncTask<String, String, String>
	{
		@Override
		protected void onProgressUpdate(String[] values)
		{
			super.onProgressUpdate(values);
			if("html".equals(values[0])) {
				console.append(Html.fromHtml(values[1]));
			} else if("normal".equals(values[0])) {
				console.append(values[1]);
			}
			tscroll.fullScroll(tscroll.FOCUS_DOWN);
			tscroll.scrollTo(0, tscroll.getBottom());
		}
		@Override
		protected String doInBackground(String[] params)
		{
			try {
				publishProgress("html", String.format("<font color='yellow'>[%d:%d:%d] sqldump running...</font><br>", new Date().getHours(), new Date().getMinutes(), new Date().getSeconds()));
				BufferedReader br = new BufferedReader(new InputStreamReader(new URL("https://www.google.com/search?q="+params[0]).openConnection().getInputStream()));
				String content = "";String inputLine;
				while((inputLine=br.readLine())!=null) {
					content+=inputLine+"\n";
				}
				results = "";
				totalResult = 0;
				Document doc = Jsoup.parse(content);
				Elements links = doc.select("a[href]");
				for(int x = 0;x < links.size();x++) {
					if(links.get(x).attr("href").startsWith("http") && Pattern.compile(Pattern.quote(".php?")).matcher(links.get(x).attr("href")).find()) {
						String link = links.get(x).attr("href");
						try {
							BufferedReader request = new BufferedReader(new InputStreamReader(new URL(link+"'").openConnection().getInputStream()));
							String body = "";String getLine;
							while((getLine = request.readLine())!=null) {
								body+=getLine+"\n";
							}
							if(Pattern.compile(Pattern.quote("You have an error in your SQL syntax,supplied argument is not a valid MySQL result resource,check the manual that corresponds to your MySQL,mysql_fetch_array(),supplied argument is not a valid MySQL,function fetch_row(),Microsoft OLE DB Provider for ODBC Drivers error,MySQL Error,Database error,Division by zero in,Microsoft JET Database,ODBC Microsoft Access Driver,Microsoft OLE DB Provider for,Unclosed quotation mark,Incorrect syntax near,SQL query failed,Warning: filesize(),Warning: preg_match(),Warning: array_merge(),Warning: mysql_query(),Warning: mysql_num_rows(),Warning: session_start(),Warning: getimagesize(),Warning: mysql_fetch,Warning: is_writable(),Warning: Unknown(),Warning: mysql_result(),Warning: pg_exec(),Warning: require()")).matcher(body).find()) {
								publishProgress("html", String.format("<font color='#008B10'>[%s:%s:%s] </font><font color='green'>%s</font><br>", new Date().getHours(), new Date().getMinutes(), new Date().getSeconds(), link));
								results+=String.format("%s: VULN\n", link);
							} else {
								publishProgress("html", String.format("<font color='red'>[%s:%s:%s] </font><font color='yellow'>%s</font><br>", new Date().getHours(), new Date().getMinutes(), new Date().getSeconds(), link));
								results+=String.format("%s: NOT VULN\n", link);
							}
							
						} catch(Exception ex) {
							publishProgress("html", String.format("<font color='blue'>[%s:%s:%s] </font><font color='cyan'>%s</font><br>", new Date().getHours(), new Date().getMinutes(), new Date().getSeconds(), link));
							results+=String.format("%s: MIGHT VULN\n", link);
						}
						totalResult+=1;
					}
				}
				publishProgress("normal", String.format("[%s:%s:%s] Total: %s results found\n", new Date().getHours(), new Date().getMinutes(), new Date().getSeconds(), totalResult));
				return null;
			} catch(Exception e) {
				publishProgress("normal", e.toString()+"\n");
				return null;
			}
		}
		@Override
		protected void onPostExecute(String result) {}
	}
	public void banner() {
		console.append("              __    __                      \n");
		console.append("  _____ _____|  |__|  |__ __ ________ _____ \n");
		console.append(" |__ --|  _  |  |  _  |  |  |        |  _  |\n");
		console.append(" |_____|__   |__|_____|_____|__|__|__|   __|\n");
		console.append("          |__|                       |__|   \n\n");
	}
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		try {
			ProviderInstaller.installIfNeeded(getApplicationContext());
			SSLContext sslContext;
			sslContext = SSLContext.getInstance("TLSv1.2");
			sslContext.init(null, null, null);
			sslContext.createSSLEngine();
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), "Google Play Services is not available!", Toast.LENGTH_SHORT).show();
		}
		getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00FF00")));
		tscroll = (ScrollView) findViewById(R.id.tscroll);
		console = (TextView) findViewById(R.id.console);
		dork = (EditText) findViewById(R.id.dork);
		findViewById(R.id.copy).setOnClickListener(copy_to);
		findViewById(R.id.dump).setOnClickListener(dump);
		findViewById(R.id.stask).setOnClickListener(startTask);
		banner();
		File sqldump = new File(Environment.getExternalStorageDirectory().toString()+"/sqldump");
		if(sqldump.exists()) {
			if(sqldump.isFile()) {
				sqldump.delete();
				sqldump.mkdir();
			}
		} else {
			sqldump.mkdir();
		}
    }
	View.OnClickListener startTask = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			dork.onEditorAction(EditorInfo.IME_ACTION_DONE);
			mTask = new GoogleSearchTask();
			mTask.execute(dork.getText().toString());
		}
	};
	View.OnClickListener copy_to = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			if(totalResult != 0) {
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
					final android.content.ClipboardManager clipboardManager = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					final android.content.ClipData clipData = android.content.ClipData.newPlainText(null, results);
					clipboardManager.setPrimaryClip(clipData);
				} else {
					final android.text.ClipboardManager clipboardManager = (android.text.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
					clipboardManager.setText(results);
				}
				Toast.makeText(getApplicationContext(), "Copied to clipboard!", Toast.LENGTH_SHORT).show();
			}
		}
	};
	View.OnClickListener dump = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			if(totalResult != 0) {
				try {
					String pathfile = String.format("%s/sqldump/result.txt", Environment.getExternalStorageDirectory().toString());
					FileOutputStream out = new FileOutputStream(pathfile);
					out.write(results.getBytes());
					out.close();
					Toast.makeText(getApplicationContext(), String.format("Output: %s", pathfile), Toast.LENGTH_SHORT).show();
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	};
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId()) {
			case R.id.clear: console.setText("");banner();
				break;
			case R.id.about: new AlertDialog.Builder(MainActivity.this).setTitle("sqldump").setMessage("Dump sql sites result with easy\nVersion 1.0\n\n# Color Sign\nOld Green + Green = Vuln\nBlue + Cyan = Might Vuln\nRed + Yellow = Not Vuln\n\n# Contact\nInstagram: @dtlily\nTelegram: @dtlily\nFacebook: cgi.izo\nLine: dtl.lily\nGitHub: Gameye98\nGitLab: dtlily\nYoutube: dtlily\n\nCopyright (C) 2019 by DedSecTL\n\nDedSecTL\nMr.KaitoX\nCvar1984\nCiKu370\nMr.TenSwapper07\namsitlab\n[M]izuno\n3RROR_TMX\nMr.K3N\nZetSec\nTroublemaker97\nL_Viole\nX14N23N6\nMR.R45K1N\nlord.zephyrus\n4cliba788\nmr0x100\nMrx04\nViruz\nMr_007\nITermSec\nIdannovita.\nBlackHole Security.").setPositiveButton("OK", null).show().getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00FF00")));
				break;
		}
		return true;
	}
}
