package com.kaitocoder.backpressed;

import android.app.*;
import android.os.*;
import android.view.View.*;
import android.content.*;
import android.text.*;
import android.widget.*;
import java.net.*;
import java.util.*;
import java.io.*;
import android.content.res.*;
import android.view.*;


public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
}
			


	@Override
	public void onBackPressed()
	{
		new AlertDialog.Builder(MainActivity.this)
			.setTitle("BackPressed - Dialog")
			.setMessage("")
			
			.setNeutralButton("About", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialogInterface, int whichButton) {
					new AlertDialog.Builder(MainActivity.this)
						.setMessage(" Developed : Kaito\n Team: Barayong Developers")
						.setPositiveButton("OK",null)
						.show();
				}
			})
			.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialogInterface, int whichButton) {
					finish();
				}
			})
			.show();
		
						
						
    }
}
