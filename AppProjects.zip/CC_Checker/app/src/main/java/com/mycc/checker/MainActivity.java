package com.mycc.checker;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import android.text.*;

public class MainActivity extends Activity 
{

	private static TextView result;
	

	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		// Create Folder
		findViewById(R.id.start).setOnClickListener(start);
		File Cc_Checker = new File("/sdcard/Cc_Checker");
		if(Cc_Checker.exists()){
			if (Cc_Checker.isFile()){
				Cc_Checker.delete();
				Cc_Checker.mkdir();
			}
			else{
				Cc_Checker.mkdir();
			}
		}
		
		// View ID
		result = (TextView) findViewById(R.id.result);
		findViewById(R.id.about).setOnClickListener(about);
		findViewById(R.id.exit).setOnClickListener(exit);
		
}
        // Start
	View.OnClickListener start = new View.OnClickListener() {

		@Override
		public void onClick(View view){
		Toast.makeText(getApplicationContext(), "Please Wait..", Toast.LENGTH_SHORT).show();
		
	}
};
			

		// About
		
	View.OnClickListener about = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			new AlertDialog.Builder(MainActivity.this)
				.setMessage("Cc Checker is a simple program to check cc valid or invalid type\n\nContact Me\n\nFacebook: www.facebook.com/kaito.legion.7\nYouTube: www.youtube.com/kaitolegion\n\nCopyright (C) 2019 By Mr.KaitoX\n\nBlackHoleSecurity\nPinoyRootSec")
				.setPositiveButton(android.R.string.ok,null)
				.show()
				.getWindow()
				.setBackgroundDrawableResource(android.R.color.holo_green_dark);
		}
	};
		
		// Exit
		     View.OnClickListener exit = new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				finish();
			}
		};
		
		
	
}
