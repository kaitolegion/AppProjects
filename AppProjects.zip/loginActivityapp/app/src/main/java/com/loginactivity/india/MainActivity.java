package com.loginactivity.india;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import com.google.firebase.auth.*;
import com.google.android.gms.tasks.*;
import android.content.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends AppCompatActivity 
{
	private EditText email, password;
	private Button login,signup;
	private FirebaseAuth mAuth;
	private FirebaseAuth.AuthStateListener listner;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		email = (EditText) findViewById(R.id.activitymainEditTextemai);
		password = (EditText) findViewById(R.id.activitymainEditTextpassword);
        login = (Button) findViewById(R.id.activitLogin);
		signup = (Button) findViewById(R.id.activitySignup);
		
		listner = new FirebaseAuth.AuthStateListener(){

			@Override
			public void onAuthStateChanged(FirebaseAuth p1)
			{
				// TODO: Implement this method
				if(p1.getCurrentUser() != null){
		       Intent i = new Intent(MainActivity.this,SignUpCompletectivity.class);
				startActivity(i);
					}
				
			}		
		};
		
		
	    mAuth = FirebaseAuth.getInstance();
		login.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					login();
				}

			
		});
		signup.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					Signup();
				}

				});
		
		
		
		}
		private void Signup(){
			String e = email.getText().toString();
			String p = password.getText().toString();
			if(e.isEmpty()){

				return;
			}
			if(p.isEmpty()){

				return;
			}
  mAuth.createUserWithEmailAndPassword(e,p)
	  .addOnCompleteListener(this, new OnCompleteListener<AuthResult>(){
					@Override
					public void onComplete(Task<AuthResult> task)
					{
						// TODO: Implement this method
					if(task.isSuccessful()){
				     Toast.makeText(MainActivity.this,"sucessfully sign up",Toast.LENGTH_LONG).show();
					 return;
					}else{
				    Toast.makeText(MainActivity.this,"sign up failed",Toast.LENGTH_LONG).show();
					}
					}		
			});
		}
		private void login(){
			String e = email.getText().toString();
			String p = password.getText().toString();
			if(e.isEmpty()){
				
				return;
			}
			if(p.isEmpty()){
				
				return;
			}
			mAuth.signInWithEmailAndPassword(e, p).addOnCompleteListener(this, new OnCompleteListener<AuthResult>(){
					@Override
					public void onComplete(Task<AuthResult> task)
					{
						// TODO: Implement this method
						if(task.isSuccessful()){
							Toast.makeText(MainActivity.this,"sucessfully sign in",Toast.LENGTH_LONG).show();
							Intent i = new Intent(MainActivity.this,SignUpCompletectivity.class);
							startActivity(i);
						}else{
							Toast.makeText(MainActivity.this,"sign in failed",Toast.LENGTH_LONG).show();
						}
						
					}			
			});
		}

		@Override
		protected void onStart()
		{
			// TODO: Implement this method
			super.onStart();
			mAuth.addAuthStateListener(listner);
		}
		
}
