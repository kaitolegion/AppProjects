package com.loginactivity.india;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import com.google.firebase.auth.*;

public class SignUpCompletectivity extends Activity 
{
	FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_complete);
		
		findViewById(R.id.signupcompleteButtonLogout)
			.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					// TODO: Implement this method
					auth = FirebaseAuth.getInstance();
					auth.signOut();
					Intent i = new Intent(SignUpCompletectivity.this,MainActivity.class);
					startActivity(i);
					finish();
				}		
		});
    }
}
