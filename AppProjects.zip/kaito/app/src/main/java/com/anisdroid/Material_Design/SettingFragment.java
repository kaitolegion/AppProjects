package com.anisdroid.Material_Design;
import android.app.*;
import android.view.*;
import android.os.*;

public class SettingFragment extends Fragment
{

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		return inflater.inflate(R.layout.fragment_setting,container,false);
	}
	
}
