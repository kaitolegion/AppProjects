package com.anisdroid.Material_Design;

import android.content.*;
import android.os.*;
import android.support.design.widget.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import android.support.v7.widget.Toolbar;
import android.app.*;

public class MainActivity extends ActionBarActivity 
{
	private FloatingActionButton fab;
	private Toolbar ttt;
	FragmentTransaction ft;
	// Hamburger
	DrawerLayout dl;
	ActionBarDrawerToggle abt;
	// Hamburger

	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		
		ttt = (Toolbar) findViewById(R.id.app_bar);
		setSupportActionBar(ttt);
		
		
		
		// Hamburger Icon
		
		dl = (DrawerLayout) findViewById(R.id.drawer_layout);
		
		abt = new ActionBarDrawerToggle(this,dl,ttt,R.string.drawer_open,R.string.drawer_closed);
		
		dl.setDrawerListener(abt);
		abt.syncState();
		
		// Hambuger Icon
		
		ft = getFragmentManager().beginTransaction();
		ft.add(R.id.frame_container,new MainFragment());
		ft.commit();
		

}
	@Override
	public boolean onCreateOptionsMenu(Menu aaa)
	{
		MenuInflater bbb = getMenuInflater();
		bbb.inflate(R.menu.my_menu,aaa);
		
		// TODO: Implement this method
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem ccc)
	{
		if(ccc.getItemId() == R.id.about){
			startActivity(new Intent(this,About.class));
		}
		
		// TODO: Implement this method
		return true;
	}
	
	
	
}
