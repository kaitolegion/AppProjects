package com.appbar.mrkaitox;

import android.app.*;
import android.os.*;

public class ExampleTwoActivity extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Toolbar toolbar = (Toolbar) findViewById(R.id.appbar);
		//This enables the back arrow on the app bar. getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		toolbar.setNavigationOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View view) {
					finish();
				}
			});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		getMenuInflater().inflate(R.menu.example_two,menu);
		return super.onCreateOptionsMenu(menu);

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()){

			case R.id.twosettings:
				Toast.makeText(this,Settings,Toast.LENGTH_SHORT).show();
				break;
			case R.id.favorites:
				Toast.makeText(this,Replace with your own action,Toast.LENGTH_SHORT).show();
				break;
			case R.id.search:
				Toast.makeText(this,Replace with your own actions.,Toast.LENGTH_SHORT).show();
				break;

		}

		return super.onOptionsItemSelected(item);

	}

}
