package sec.blackhole.wipgrab;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.text.ClipboardManager;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;
import android.content.*;

public class MainActivity extends Activity 
{
	public class SendTask extends AsyncTask<String, Void, String>
	{
		@Override
		protected String doInBackground(String[] paramsOf)
		{
			try {
				BufferedReader br = new BufferedReader(new InputStreamReader(new URL("https://tools.keycdn.com/geo.json?host="+paramsOf[0]).openConnection().getInputStream()));
				String content = "";String inputLine;
				while((inputLine=br.readLine())!=null) {
					content = content + inputLine + "\n";
				}
				return content;
			} catch(Exception e) {
				return "NetworkError";
			}
		}
		@Override
		protected void onPostExecute(String result)
		{
			if("NetworkError".equals(result)) {
				new AlertDialog.Builder(MainActivity.this)
				.setMessage("Device is not connected to the internet")
				.setPositiveButton(android.R.string.ok,null)
				.show()
				.getWindow()
				.setBackgroundDrawableResource(android.R.color.holo_red_dark);
			} else {
				TextView ipaddr = (TextView) findViewById(R.id.ipaddr);
				try {
					JSONObject obj = new JSONObject(result);
					JSONObject data = obj.getJSONObject("data").getJSONObject("geo");
					ipaddr.setText(data.getString("ip"));
				} catch(Exception e) {
					new AlertDialog.Builder(MainActivity.this)
					.setMessage("Something went error...")
					.setPositiveButton(android.R.string.ok,null)
					.show()
					.getWindow()
					.setBackgroundDrawableResource(android.R.color.holo_red_dark);
				}
			}
		}
	}


	
	
	//Layout ID Click Listener
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		findViewById(R.id.ipaddr).setOnClickListener(ipaddr);
		findViewById(R.id.loginfb).setOnClickListener(loginfb);
		findViewById(R.id.grab).setOnClickListener(grab);
		findViewById(R.id.about).setOnClickListener(about);
		findViewById(R.id.contact).setOnClickListener(contact);
		findViewById(R.id.exit).setOnClickListener(exit);
	}
	
	//Ipaddr
	View.OnClickListener ipaddr = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			TextView ipaddr = (TextView) findViewById(R.id.ipaddr);
			if(!"- - -".equals(ipaddr.getText().toString())) {
				android.text.ClipboardManager clipboard = (android.text.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
				clipboard.setText(ipaddr.getText().toString());
				Toast.makeText(getApplicationContext(), "Copied to clipboard!", Toast.LENGTH_SHORT).show();
			}
		}
	};
	
	//LoginFb
	View.OnClickListener loginfb = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			new AlertDialog.Builder(MainActivity.this)
				.setMessage("Facebook: @kaito.gov.ph\nTelegram: @kaitools\nFB-Page: @KaitoXspiker\nGitHub: MrKaitoX\nGitLab: MrKaitoX\nYoutube: Mr.KaitoX")
				.setPositiveButton(android.R.string.ok,null)
				.show()
				.getWindow()
				.setBackgroundDrawableResource(android.R.color.holo_blue_dark);
		}
	};
	
	
	//grab
	View.OnClickListener grab = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			EditText domain = (EditText) findViewById(R.id.domain);
			if(!"".equals(domain.getText().toString())) {
				new SendTask().execute(domain.getText().toString());
			} else {
				//nothing to do
			}
		}
	};
	
	
	
	// Contact
	View.OnClickListener contact = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			new AlertDialog.Builder(MainActivity.this)
			.setMessage("Facebook: @kaito.gov.ph\nTelegram: @kaitools\nFB-Page: @KaitoXspiker\nGitHub: MrKaitoX\nGitLab: MrKaitoX\nYoutube: Mr.KaitoX")
			.setPositiveButton(android.R.string.ok,null)
			.show()
			.getWindow()
			.setBackgroundDrawableResource(android.R.color.holo_blue_dark);
		}
	};
	
	
	// About
	
	View.OnClickListener about = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			new AlertDialog.Builder(MainActivity.this)
			.setMessage("Help you to grab any websites IP\n\nCopyright (C) 2019 By KaitoX\n\nDedSecTL\nCvar1984\nCiKu370\nMr.TenSwapper07\namsitlab\n[M]izuno\n3RROR_TMX\nMr.K3N\nZetSec\nTroublemaker97\nL_Viole\nX14N23N6\nMR.R45K1N\nlord.zephyrus\n4cliba788\nmr0x100\nMrx04\nViruz\nMr_007\nITermSec\nIdannovita.\nBlackHole Security.")
			.setPositiveButton(android.R.string.ok,null)
			.show()
			.getWindow()
			.setBackgroundDrawableResource(android.R.color.holo_green_dark);
		}
	};
	
	
	// Exit
	View.OnClickListener exit = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			finish();
		}
	};

	
	
	// On Backpressed
	@Override
	public void onBackPressed()
	{
		//nothing to do
		

		
	}
	
}
