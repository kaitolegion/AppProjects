package com.kaito.button;

import android.app.*;
import android.os.*;
import android.view.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		findViewById(R.id.About).setOnClickListener(About);
		}
		
		View.OnClickListener About = new View.OnClickListener() 
		{
			
			@Override
			public void onClick(View view) {
				new AlertDialog.Builder(MainActivity.this)
					.setMessage("About")
					.setPositiveButton(android.R.string.ok,null)
					.show()
					.getWindow()
					.setBackgroundDrawableResource(android.R.color.holo_blue_dark);
			}
		};
		
		
}
