package com.mybackpress.alert;

import android.app.*;
import android.content.*;
import android.os.*;

public class MainActivity extends Activity 
{
	
	// Main Layout
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

	// BackPress Dialog
	@Override
	public void onBackPressed()
	{
		new AlertDialog.Builder(MainActivity.this)
			.setTitle("Do you want to exit.")
			.setNegativeButton("Cancel",null)
			.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialogInterface, int whichButton) {
					finish();
				}
			})
		    .show();
			
			
	}
}
