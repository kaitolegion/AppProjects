package com.mrkaitox.Yahoochecker;

import android.app.*;
import android.os.*;
import android.view.View.*;
import android.content.*;
import android.text.*;
import android.widget.*;
import java.net.*;
import java.util.*;
import java.io.*;
import android.content.res.*;
import android.view.*;
import android.text.ClipboardManager;
import org.json.*;
import android.widget.Toast;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		}
		
		public void Click (View view){
			Toast.makeText(getApplicationContext(),"Activate Please Wait..",Toast.LENGTH_SHORT).show();
		}
		
		public void Contact(View view){
			
			new AlertDialog.Builder(MainActivity.this)
				.setTitle("Contact Me")
				.setMessage("Facebook : \n Github : \n Telegram :")
					
				.show();
		}
		
	
	@Override
	public void onBackPressed()
	{
		new AlertDialog.Builder(MainActivity.this)
			.setTitle("About | Yahoo Checker")
			.setMessage("")

			.setNeutralButton("About", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialogInterface, int whichButton) {
					new AlertDialog.Builder(MainActivity.this)
						.setMessage(" Developed : Kaito\n Team: Barayong Developers")
						.setPositiveButton("OK",null)
						.show();
				}
			})
			.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialogInterface, int whichButton) {
					finish();
				}
			})
			.show();

	}
}
