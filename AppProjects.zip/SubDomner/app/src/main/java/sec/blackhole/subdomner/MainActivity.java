package sec.blackhole.subdomner;

import android.app.*;
import android.os.*;
import android.view.View.*;
import android.content.*;
import android.text.*;
import android.widget.*;
import java.net.*;
import java.util.*;
import java.io.*;
import android.content.res.*;
import android.view.*;

public class MainActivity extends Activity 
{
	public class SendTask extends AsyncTask<String, Void, String>
	{
		@Override
		protected String doInBackground(String[] list)
		{
			TextView xterm = (TextView) findViewById(R.id.xterm);
			String[] wordlist = list[0].split(",");
			for(int x = 0;x < wordlist.length;x++) {
				try {
					HttpURLConnection conn = (HttpURLConnection) new URL("https://"+wordlist[x]+"."+list[1]).openConnection();
					conn.setConnectTimeout(500);
					conn.setRequestMethod("GET");
					if(conn.getResponseCode() == 200) {
						xterm.append(Html.fromHtml("<font color='green'>[+]</font> <font color='yellow'>"+wordlist[x]+"."+list[1]+"</font><br>"));
					} else {
						xterm.append(Html.fromHtml("<font color='red'>[-] "+wordlist[x]+"."+list[1]+"</font><br>"));
					}
					conn.disconnect();
				} catch(Exception e) {
					//xterm.append(Html.fromHtml("<font color='red'>"+e+"</font><br>"));
				}
			}
			return null;
		}
		@Override
		protected void onPostExecute(String result)
		{
			TextView xterm = (TextView) findViewById(R.id.xterm);
			xterm.append(Html.fromHtml("<font color='red'>[!]</font> <font color='white'>Done ...</font><br>"));
		}
		
	}
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		TextView xterm = (TextView) findViewById(R.id.xterm);
		xterm.append("#####################################################\n#                    Test App                       #\n#               Anonymous Deforce Army              #\n#                   20 - July - 2019                #\n#####################################################\n\n");
    }
	@Override
	public void onBackPressed()
	{
		new AlertDialog.Builder(MainActivity.this)
		.setTitle("SubDomner")
		.setMessage("")
		.setPositiveButton("Action", new DialogInterface.OnClickListener() {
			
			
			public void onClick(DialogInterface dialogInterface, int whichButton) {
				AlertDialog.Builder actionDlg = new AlertDialog.Builder(MainActivity.this);
				final EditText input = new EditText(MainActivity.this);
				input.setHint("example.com");
				input.setGravity(Gravity.CENTER);
				actionDlg.setView(input);
				actionDlg.setPositiveButton("Small Wordlist", new DialogInterface.OnClickListener() {
					
					
					public void onClick(DialogInterface dialogInterface, int whichButton) {
						TextView xterm = (TextView) findViewById(R.id.xterm);
						xterm.append(Html.fromHtml("<font color='green'>[+]</font><font color='white'> Target : "+input.getText().toString()+"</font><br>"));
						try {
							AssetManager assetManager = getAssets();
							InputStream inputLine = assetManager.open("small.list");
							int size = inputLine.available();
							byte[] buffer = new byte[size];
							inputLine.read(buffer);
							inputLine.close();
							String text = new String(buffer);
							new SendTask().execute(text.replace("\n",",").replace("\n",""),input.getText().toString());
						} catch(Exception e) {
							
							
							new AlertDialog.Builder(MainActivity.this)
							.setTitle("")
							.setMessage(""+e)
							.setPositiveButton("OK",null)
							.show();
						}
					}
				});
				actionDlg.setNegativeButton("Big Wordlist", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialogInterface, int whichButton) {
						try {
							BufferedReader br = new BufferedReader(new InputStreamReader(getAssets().open("big.list")));
							String inputLine;String text = "";
							while((inputLine = br.readLine())!=null) {
								text = text + inputLine + "\n";
							}
							new SendTask().execute(text.replace("\n",",").replace("\n",""),input.getText().toString());
						} catch(Exception e) {
							new AlertDialog.Builder(MainActivity.this)
								.setTitle("")
								.setMessage("")
								.setPositiveButton("OK",null)
								.show();
						}
					}
				});
				actionDlg.setNeutralButton("Cancel",null);
				actionDlg.show();
			}
		})
		
		.setNeutralButton("Contact", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialogInterface, int whichButton) {
				new AlertDialog.Builder(MainActivity.this)
				.setMessage("Instagram: @dtlily\nTelegram: @dtlily\nFacebook: cgi.izo\nLine: dtl.lily\nGitHub: Gameye98\nGitLab: dtlily\nYoutube: dtlily")
				.setPositiveButton("OK",null)
				.show();
			}
		})
		.setNegativeButton("Exit", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialogInterface, int whichButton) {
				finish();
			}
		})
		.show();
	}
}
